﻿window.triggerFileInput = function () {
    let fileInput = document.getElementById("fileInput");
    fileInput.click();
};
